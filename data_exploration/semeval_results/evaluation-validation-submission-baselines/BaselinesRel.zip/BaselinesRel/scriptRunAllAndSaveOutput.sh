
output=baselines.results
echo -e "Running all and save output to:" $output 
bash scriptRunAll.sh | tee baselines.results
