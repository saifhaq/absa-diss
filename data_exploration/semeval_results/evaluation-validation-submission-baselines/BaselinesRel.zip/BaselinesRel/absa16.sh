#!/bin/bash
clear

# Baselines folder (full path)
dir=$(pwd)/

echo -e $dir$1
echo "Reading config...." >&2
. $dir$1

echo -e "Started.." $dir$1

# ttd full path
pth=$dir$ttd/


# ---------------------------------------------------

ABSABaseAndEval ()
{

if [ "$skip" -ne 1 ]; then
echo -e "***** Harvesting Features from Train *****"
java -cp ./A.jar absa16.Do ExtractFeats $dom $dir $ttd $lang $ftr$pIdxArg 

echo -e "***** Creating Train Vectors for Stages 1 and 2 *****"
java -cp ./A.jar absa16.Do CreateVecs $dom $dir $ttd $lang 1 "1"$pIdxArg 

echo -e "***** Training SVM model for category  prediction *****"
./libsvm-3.18/svm-train -t 0 -b 1 -q ${pth}"tr.svm.asp"${suff} ${pth}"tr.svm.model.asp"${suff} 
fi

# Stage 1 Predict

echo -e "***** Creating Test Vectors for Stage 1 *****"
java -cp ./A.jar absa16.Do CreateVecs $dom $dir $ttd $lang 2 "1"$pIdxArg

echo -e "***** Predict categories *****"
./libsvm-3.18/svm-predict -b 1 ${pth}"te.svm.asp"${suff} ${pth}"tr.svm.model.asp"${suff} ${pth}"Out.asp"${suff}

echo -e "***** Assigning categories using a threshold on the SVM prediction *****"
java -cp ./A.jar absa16.Do Assign $dom $dir $ttd $thr 1 "0"$pIdxArg

if [ "$OTE" -eq 1 ]; then 
echo -e "***** Determining targets using a target list created from train data *****"
java -cp ./A.jar absa16.Do IdentifyTargets $dom $dir $ttd $pIdxArg
fi

# Stage 2 Training

if [ "$skip" -ne 1 ]; then

echo -e "***** Training polarity category model *****"
./libsvm-3.18/svm-train -t 0 -b 1 -q ${pth}"tr.svm.pol"${suff} ${pth}"tr.svm.model.pol"${suff}

fi

# Stage 2 Predict

echo -e "***** Creating Test Vectors for Stage 2 *****"
java -cp ./A.jar absa16.Do CreateVecs $dom $dir $ttd $lang 2 "2"$pIdxArg

# gold aspects 
echo -e "***** Predicting polarities using SVM for gold aspect categories *****"
./libsvm-3.18/svm-predict -b 1 ${pth}"te.svm.pol4g"${suff} ${pth}"tr.svm.model.pol"${suff} ${pth}"Out.pol"${suff}

echo -e "***** Assigning polarities based on SVM prediction *****"
java -cp ./A.jar absa16.Do Assign $dom $dir $ttd 0 2 "0"$pIdxArg

# pred aspects 
echo -e "***** Predicting polarities using SVM for predicted aspect categories *****"
./libsvm-3.18/svm-predict -b 1 ${pth}"te.svm.pol4p"${suff} ${pth}"tr.svm.model.pol"${suff} ${pth}"Out.pol"${suff}

echo -e "***** Assigning polarities based on SVM prediction *****"
java -cp ./A.jar absa16.Do Assign $dom $dir $ttd 0 2 "1"$pIdxArg

# Evaluate results

#echo -e "\n"
echo -e "***** SB1: Evaluate Stage 1 Output (target and category) *****"

java -cp ./A.jar absa16.Do Eval -prd ${pth}"teCln.PrdAspTrg.xml"${suff} -gld ${pth}"teGld.xml"${suff} -evs 1 -phs A -sbt SB1

if [ "$OTE" -eq 1 ]; then 
java -cp ./A.jar absa16.Do Eval -prd ${pth}"teCln.PrdAspTrg.xml"${suff} -gld ${pth}"teGld.xml"${suff} -evs 2 -phs A -sbt SB1
java -cp ./A.jar absa16.Do Eval -prd ${pth}"teCln.PrdAspTrg.xml"${suff} -gld ${pth}"teGld.xml"${suff} -evs 3 -phs A -sbt SB1
fi

echo -e "*****SB1: Evaluate Stage 2 Output (Polarity) *****"
java -cp ./A.jar absa16.Do Eval -prd ${pth}"teGldAspTrg.PrdPol.xml"${suff} -gld ${pth}"teGld.xml"${suff} -evs 5 -phs B -sbt SB1

echo -e "\n"

if [ "$SB2" != "" ]; then 
# data are available for SB2

if [ "$wt" -eq 1 ]; then
SB2=$SB2Test
fi

echo -e "Create:" ${pth}"teGldSB2.xml"${suff} " From: " ${pth}"teGld.xml"${suff}
java -cp ./A.jar absa16.Do SB1TOSB2GOLD ${pth}"teGld.xml"${suff} ${dir}${SB2} ${pth}"teGldSB2.xml"${suff}

echo -e "***** SB2: Evaluate Stage 1 Output (Category) *****"
java -cp ./A.jar absa16.Do SB1TOSB2ASPECTS ${pth}"teCln.PrdAspTrg.xml"${suff} ${pth}"teCln.PrdAspTrgSB2.xml"${suff} ${dir}${SB2}
java -cp ./A.jar absa16.Do Eval -prd ${pth}"teCln.PrdAspTrgSB2.xml"${suff} -gld ${pth}"teGldSB2.xml"${suff} -evs 1 -phs A -sbt SB2

echo -e "***** SB2: Evaluate Stage 2 Output (Polarity) *****"
java -cp ./A.jar absa16.Do SB1TOSB2POL ${pth}"teGldAspTrg.PrdPol.xml"${suff} ${pth}"teGldSB2.xml"${suff} ${pth}"teGldAspTrg.PrdPolSB2.xml"${suff}
java -cp ./A.jar absa16.Do Eval -prd ${pth}"teGldAspTrg.PrdPolSB2.xml"${suff} -gld ${pth}"teGldSB2.xml"${suff} -evs 5 -phs B -sbt SB2

fi

}

echo -e "*******************************************"
echo -e "BASELINES DIR:" $dir
echo -e "Stage 1: Aspect and OTE extraction"
echo -e "Stage 2: Polarity classification"

if [ "$wt" -eq 0 ]; then 
	# split mode

	echo -e "***** Validate Input XML *****"
	java -cp ./A.jar absa16.Do Validate ${dir}${SB1} ${dir}"ABSA16.xsd" $dom
	
	if [ "$xva" -eq 0 ]; then 
		# train-test split
		if [ "$skip" -ne 1 ]; then
			echo -e "***** Split Train Test *****"		
			java -cp ./A.jar absa16.Do Split $sfl $dir $ttd $SB1 $fld $partIdx 
		fi
		ABSABaseAndEval 
	else 
		# cross validation split
		if [ "$skip" -ne 1 ]; then
			echo -e "***** Split *****" 	
			java -cp ./A.jar absa16.Do Split $sfl $dir $ttd $SB1 $fld
		fi
		echo -e "\n***** Cross Validation*****\n"
		for i in $(eval echo {1..$fld}); do	  		  
	  	echo -e "Round " $i	  	  	  
	 	pIdxArg=" "$(($i-1))
	  	suff="."$(($i-1))
	  	echo $pIdxArg $suff
	  	ABSABaseAndEval
	  	echo -e "\n"
	done
	fi
elif [ "$wt" -eq 1 ]
then 
	# no split is needed
        # just copy the needed files to the ttd dir.
        java -cp ./A.jar absa16.Do PrepareTestRun $dir $ttd $SB1 $SB1Test
	ABSABaseAndEval
else
  	echo -e "wt: no valid value"
fi

echo -e "Done.." $dir$1
echo -e "*******************************************"


