#property=wt
#value=1

sed -i "s/\(${property}=\).*\$/\1${value}/" cfg*
