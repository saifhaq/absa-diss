cat $1 | grep "F-MEASURE="
cat $1 | grep "Accuracy:"
