rm -rfv Files_*/*
